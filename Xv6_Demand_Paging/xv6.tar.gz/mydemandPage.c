#include "types.h"
#include "stat.h"
#include "user.h"

#define N 3000

int glob[N];

int main (){

    glob[0]=7;

    printf(1,"global addr from user space:%x\n",glob);

    for (int i=1;i<N;i++){

        glob[i]=glob[i-1];

         if (i%1000==0){

            pgtPrint();

         }
    }

    printf(1,"Printing final page table :\n");

    pgtPrint();

    printf(1,"Value : %d\n",glob[N-1]);

    exit();




}