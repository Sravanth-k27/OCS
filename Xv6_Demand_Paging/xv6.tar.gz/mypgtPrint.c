#include "types.h"
#include "user.h"

int arrGlobal[10000];

int main (){

    int arrLocal[10];
    
    for (int i=0;i<10;i++){
        arrLocal[i]=10;
    }

    printf(2,"value is %d\n",arrLocal[0]); 

    pgtPrint();
    exit();
    return 0;

}