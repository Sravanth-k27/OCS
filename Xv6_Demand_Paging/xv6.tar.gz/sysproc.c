#include "types.h"
#include "x86.h"
#include "defs.h"
#include "date.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "proc.h"

int
sys_fork(void)
{
  return fork();
}

int
sys_exit(void)
{
  exit();
  return 0;  // not reached
}

int
sys_wait(void)
{
  return wait();
}

int
sys_kill(void)
{
  int pid;

  if(argint(0, &pid) < 0)
    return -1;
  return kill(pid);
}

int
sys_getpid(void)
{
  return myproc()->pid;
}

int
sys_sbrk(void)
{
  int addr;
  int n;

  if(argint(0, &n) < 0)
    return -1;
  addr = myproc()->sz;
  if(growproc(n) < 0)
    return -1;
  return addr;
}

int
sys_sleep(void)
{
  int n;
  uint ticks0;

  if(argint(0, &n) < 0)
    return -1;
  acquire(&tickslock);
  ticks0 = ticks;
  while(ticks - ticks0 < n){
    if(myproc()->killed){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
  }
  release(&tickslock);
  return 0;
}

// return how many clock tick interrupts have occurred
// since start.
int
sys_uptime(void)
{
  uint xticks;

  acquire(&tickslock);
  xticks = ticks;
  release(&tickslock);
  return xticks;
}

int 
sys_date(void){
  struct rtcdate * a;
  argptr(0,(void*)&a,sizeof(*a));
  cmostime(a);
  return 0;
}

int sys_pgtPrint(void){

  //address for the page directory.

  pde_t * page_dir = myproc()->pgdir ;

  //declaring variable count for storing no of pages that satisfy the condition

  int count=0;

  if (page_dir){

    //loop runs for NPDENTRIES times i.e. 1024 we have 1024 entries in page directory

    for (int i=0;i<NPDENTRIES;i++){

      //condition for checking present bit & user bit

      if((page_dir[i]&PTE_U) && (page_dir[i]&PTE_P)){

        //assigning the virtual memory of the page tables for an entry in page directory

        pte_t * page_table = P2V(PTE_ADDR(page_dir[i]));

        //loop runs for NPTENTRIES times i.e. 1024 we have 1024 entries in  each page table

        for (int j=0 ; j<NPTENTRIES;j++){

          //condition for checking present bit & user bit
        
          if ((page_table[j] & PTE_P) && (page_table[j] & PTE_U)){

            cprintf("pgdir entry num : %d , Pgt entry num : %d , Virtual address : %x , Physical address : %p\n",i,j,(i<<22)|(j<<12),PTE_ADDR(page_table[j])) ;

            //Increasing the count 

            count++;
          }

        }
      }
    }
  }

  cprintf("No of pages that satisfy the condition are : %d\n",count);

  return 0;

}