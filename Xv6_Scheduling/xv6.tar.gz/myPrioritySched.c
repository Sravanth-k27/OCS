#include "types.h"
#include "user.h"

int main(){

    int a = fork();

    if (a==0){

        setPriority(4);

        printf(1,"Parent had created child_1\n");

        printf(1,"Printing from child_1\n");

        //just some  computations.

        int n=20;

        for (int i=0;i<2;i++){

            n=n/2;

        }

    }

    else if (a>0){

        wait();

        int b=fork();

        if (b==0){

            setPriority(3);

            printf(1,"Parent had created child_2\n");

            printf(1,"Printing from child_2\n");

            int a=2;

            int b=4;

            int c=0;

            for (int i=0;i<5;i++){

                c=c+a+b;
                
            }

        }
        else if (b>0){

            wait();

            setPriority(8);

            printf(1,"Printing from Main parent of the two children\n");

        }
    }


    exit();
}